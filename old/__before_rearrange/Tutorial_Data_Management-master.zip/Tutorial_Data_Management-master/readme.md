## Data Management
- [Data Management](lessons/data_management/lessons/data_management/readme.md)

### [Data Warehouse](lessons/data_warehouse/readme.md)

### [Data Management Processes](lessons/data_management_processes/readme.md)
- [Data Profiling](lessons/data_management_processes/lessons/data_profiling/readme.md)
---

### [ETL and ELT](lessons/etl_elt/readme.md)

### [ETL ](lessons/etl/readme.md)

### [ETL Testing](lessons/etl_testing/readme.md)


### [ELT](lessons/elt/lessons/elt/readme.md)
- [ELT Process](lessons/elt/lessons/etl_process/readme.md)

---

### [OLAP](lessons/olap/readme.md)

---

### [Test Data Management(TDM)](lessons/tdm/readme.md)
